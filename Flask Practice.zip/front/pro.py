import random
from bs4 import BeautifulSoup
import requests
import pandas as pd
from flask import Flask, render_template, request, jsonify,send_file
app = Flask(__name__)


# function for scrapping
def stock_data(n = random.choice(['ibm','goog','fb','pnb.ns'])):
        n = n.lower()
        url = 'https://in.finance.yahoo.com/quote/' + n + '?p=' + n
        page = requests.get(url)
        soup = BeautifulSoup(page.content, 'html.parser')
        name = soup.find(class_="D(ib) Fz(18px)").text
        price = soup.find(class_="Trsdu(0.3s) Fw(b) Fz(36px) Mb(-4px) D(ib)").text
        try:
            change = soup.find(class_="Trsdu(0.3s) Fw(500) Pstart(10px) Fz(24px) C($positiveColor)").text
        except:
            change = soup.find(class_="Trsdu(0.3s) Fw(500) Pstart(10px) Fz(24px) C($negativeColor)").text

        url2 = 'https://in.finance.yahoo.com/quote/' + n + '/profile?p=' + n
        page2 = requests.get(url2)
        soup2 = BeautifulSoup(page2.content, 'html.parser')
        about = soup2.find('p', class_="Mt(15px) Lh(1.6)").text
        result1 = name
        result2 = price
        result3 = change
        result4 = about

        url3 = 'https://in.finance.yahoo.com/quote/' + n + '/history?p=' + n
        page3 = requests.get(url3)
        soup3 = BeautifulSoup(page3.content, 'html.parser')

        h = soup3.find_all('thead')[0].find_all('th')
        d = soup3.find_all('tbody')[0].find_all('tr')
        s = soup3.find(class_="C($tertiaryColor) Mt(20px) Mb(15px)").text

        heading = [(i.text).replace('*', '').replace(' ', '') for i in h]
        data = []
        for c in range(len(d)):
            l = []
            for i in d[c].find_all('span'):
                l.append(i.text)
            l = tuple(l)
            data.append(l)
        data = tuple(data)
        return n,result1,result2,result3,result4,heading,data,s

n,result1,result2,result3,result4,heading,data,s = stock_data()


#dataset = pd.DataFrame(data,columns=heading)
#dataset = dataset.to_csv(n+'_stock.csv')

@app.route('/', methods=['GET', 'POST']) # To render Homepage
def main():
    return render_template('index.html',result1=result1, result2=result2, result3=result3, result4=result4,
                           heading=heading, data=data,_in=s)

"""    return render_template('index.html', result1=result1, result2=result2, result3=result3, result4=result4,
                           heading=heading, data=data,_in=s)
"""

@app.route('/home', methods=['GET', 'POST'])
def home():
    try:
        if (request.method == 'POST'):
            n = request.form['stock']
            n = n.lower()
            n, result1, result2, result3, result4, heading, data, s = stock_data(n)
            return render_template('index.html', result1=result1, result2=result2, result3=result3, result4=result4,
                                   heading=heading, data=data, _in=s)
    except:
        return render_template('index.html', result1=result1, result2=result2, result3=result3, result4=result4,
                               heading=heading, data=data, _in=s)


@app.route('/tables', methods=['GET', 'POST']) # To render Homepage
def tables():
    home()
    try:
        return render_template('tables.html',result1=result1, result2=result2, result3=result3, result4=result4,
                               heading=heading, data=data, _in=s)
    except:
        return render_template('401.html')



if __name__ == '__main__':
    app.run(debug=True)